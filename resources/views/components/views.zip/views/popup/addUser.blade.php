<!-- create/edit mountain -->
<div class="modal modal-wide fade" id="usermodal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
          <a style="padding:3px 4px 3px 6px !important;float:right;cursor:pointer;" aria-hidden="true" data-dismiss="modal" onClick="getJudgeIcons('default');"><img src="{{ asset('public/images/close.png')}}" height="20px" width="20px"></a>
          	<h4 class="modal-title">Create Judge</h4>
         </div>
		 <form class="form-horizontal" action="" method="POST" id="add_user">
        	 <div class="modal-body ">
            	<div class="row  popup-form">
               		<div class="col-md-12 center">
	                  <div class="upload-img-preview center"><img src="{{asset('public/images/img-placeholder.jpg')}}" id="user_profile_image" width="100" height="70"></div>
					 	<span id="file_error" style="color:red"></span><br/>
					 	 <div class="fileUpload btn btn-primary">
							<span>Upload Image</span>
                       		 <input type="file" class="upload" id="fileToUpload" name="fileToUpload"
                        		accept="image/jpg,image/png,image/jpeg" onchange="userimageselected(this.files)"/>
							<input type="hidden" name="userprofileImage" id="userprofileImage"/>
                 		 </div>
                 		 
			  		 </div>
					   <div class="col-md-12">
		                 <div class="row">
		                        <div class="col-xs-6">
		                            <label class="control-label" for="inputFirstName">First Name<span style="color:#ED7476">*</span></label>
		                            <input type="text" id="user_first_name" style="margin-bottom: 0px" class="form-control" required  name="user_first_name" maxlength="50">
		                        </div>
		                        <div class="col-xs-6">
		                            <label class="control-label" for="inputLastName">Last name<span style="color:#ED7476">*</span></label>
		                            <input type="text" id="user_last_name" style="margin-bottom: 0px" class="form-control" required  name="user_last_name" maxlength="50">
		                        </div>
							</div>
							<div class="row">
		                        <div class="col-xs-6">
		                            <label class="control-label" for="inputFirstName">User Name<span style="color:#ED7476">*</span></label>
		                            <input type="text" id="user_name" style="margin-bottom: 0px" class="form-control" required  name="user_name" maxlength="50">
		                        </div>
		                        <div class="col-xs-6">
		                            <label class="control-label" for="inputLastName">Password<span style="color:#ED7476">*</span></label>
		                            <input type="password" id="password" style="margin-bottom: 0px" class="form-control" required  name="password" maxlength="50">
		                        </div>
							</div>
		                    <div class="row">
		                        <div class="col-xs-6">
		                           <label class="control-label" for="inputZipTraffic">Profession<span style="color:#ED7476">*</span></label>
		                            <select class="form-control" id="user_profession" name="user_profession">
		                            @foreach($profession as $key)
		                            	<option value="{{$key->id}}">{{$key->value}}</option>
		                            @endforeach
		                            </select>
		                            
		                        </div>
		                         <div class="col-xs-6">
		                            <label class="control-label" for="inputLastName"> #Tags<span style="color:#ED7476">*</span></label>
		                            <input type="text" id="user_tags" style="margin-bottom: 0px" class="form-control" required  name="user_tags" maxlength="50">
		                        </div>
		                    </div>
		                    <div class="row">
		                        <div class="col-xs-6">
		                           <label class="control-label" for=" ">Gender<span style="color:#ED7476">*</span></label>
		                            <div class="checkbox" style="padding-left:0px!important;">
		                                <label class="checkbox-inline" style="padding-left:0px!important;">
		                                    <input type="radio" name="gender" id="gender_female" value="f" >Female
		                                </label>
		                                <label class="checkbox-inline">
		                                    <input type="radio" name="gender" id="gender_male" value="m">Male
		                                </label>
		                            </div>
	                            </div>
		                         <div class="col-xs-6">
		                            <label class="control-label" for="inputLastName">Country<span style="color:#ED7476">*</span></label>
		                             <select
					                          class="breadcrumb_mountain_property form-control" 
					                          id="user_country_id" 
					                          v-model="formVariables.country_id" 
					                         
					                  >
					                  <option 
					                      v-repeat="country: countrylist" 
					                      v-attr="selected: country.id==15"  
					                      value="@{{country.id}}"  
					                      code="@{{country.code}}"
					                     >@{{country.name}}
					                  </option>                                
					               </select>	
		                        </div>
		                       
		                    </div>
		                    <div class="row">
		                       <div class="col-xs-6">
		                            <label class="control-label" for="inputZipTraffic">Role<span style="color:#ED7476">*</span></label>
		                            <select name="user_role_type" id="user_role_type" class="form-control" required>
									  @foreach($role as $key)
		                            	<option value="{{$key->id}}">{{$key->name}}</option>
		                            @endforeach
									</select>
		                        </div>
		                       
							</div>
							<div class="row">
		                       <div class="col-xs-12">
		                            <label class="control-label" for="inputZipTraffic">Profile<span style="color:#ED7476">*</span></label>
		                            <textarea id="user_description" name="user_description" class="form-control" required   style="margin-bottom: 5px"></textarea>
		                        </div>
		                       
							</div>
							
		                    <div class="row btn-holder text-center" style=" padding-top: 20px;">
		                     <span id="user_error" class= "error_new"></span>
		                        <div class="col-xs-12">
		                        	<input type="hidden" name="judge_id" id="judge_id" value=""/>
		                            <button type="button" class="btn btn-primary" id="create_judge" v-on="click:saveUser()" >Ok</button>
		                            <button type="button" class="btn btn-default" data-dismiss="modal" onClick="getJudgeIcons('default');">Cancel</button>
		                        </div>
		                    </div>
						</div>
    				</div>
				</div>
			</form>
		</div>
	</div>
</div>


        